import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./main.css']
})
export class AppComponent {
  title = 'BankingApplication';
  // constructor(private router:Router){}
  // getHome(){
  //   this.router.navigate(['/homeLink']);
  // }
  // getLogin(){
  //   this.router.navigate(['/loginLink']);
  // }
  // getRegister(){
  //   this.router.navigate(['/registerLink']);
  // }
//   register(form:NgForm){
//     console.log(form.valid);
//     console.log(form.value);
// }
}
