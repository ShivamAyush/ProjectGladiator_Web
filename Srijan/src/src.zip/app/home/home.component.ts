import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-home',
  template: `
  <div class="row">
  <div class="main">
 
  <div class="card" style="height: 550px;">
        
      </div>
  </div>
</div>

  `,
  styleUrls: ['../main.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
